sap.ui.define(["sap/ui/core/mvc/Controller"],function(t){"use strict";return t.extend("com.pso.customerattribute.controller.App",{onInit:function(){}})});
//# sourceMappingURL=App.controller.js.map