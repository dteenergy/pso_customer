sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("com.pso.customerattribute.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  