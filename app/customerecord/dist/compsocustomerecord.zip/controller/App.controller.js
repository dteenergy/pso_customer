sap.ui.define(["sap/ui/core/mvc/Controller"],function(o){"use strict";return o.extend("com.pso.customerecord.controller.App",{onInit:function(){}})});
//# sourceMappingURL=App.controller.js.map